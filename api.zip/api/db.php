<?php

$host = "localhost"; // معمولا همین هست
$dbname = "lalanii_contactDataBase";
$username = "lalanii_mobinalalani";
$password = "YOUR_DATABASE_PASSWORD"; // رمز واقعی رو بزار اینجا

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode([
        "status" => "error",
        "message" => "Database connection failed"
    ]));
}

$conn->set_charset("utf8");
